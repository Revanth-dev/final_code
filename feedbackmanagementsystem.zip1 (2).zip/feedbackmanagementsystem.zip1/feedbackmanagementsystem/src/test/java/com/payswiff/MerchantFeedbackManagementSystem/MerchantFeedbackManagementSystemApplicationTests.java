package com.payswiff.MerchantFeedbackManagementSystem;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MerchantFeedbackManagementSystemApplicationTests {

	@Test
	void contextLoads() {
	}

}
