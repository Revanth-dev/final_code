package com.payswiff.MerchantFeedbackManagementSystem.models;

public enum UserType {
    ADMIN,
    USER,
}
